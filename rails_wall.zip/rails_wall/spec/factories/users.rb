FactoryGirl.define do
  factory :user do
    username "Peter"
  end
end

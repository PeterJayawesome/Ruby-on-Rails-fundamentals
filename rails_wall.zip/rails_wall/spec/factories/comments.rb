FactoryGirl.define do
  factory :comment do
    content "MyText"
    user nil
    message nil
  end
end
